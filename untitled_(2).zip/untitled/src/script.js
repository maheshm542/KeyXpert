/* === KeyXpert: Advanced Key Mapping System === */

/* Security Layer - Prevents Unauthorized Access */

(function() {

    const securityKey = "K3yXp3rt_53cur3";

    let accessGranted = false;

    

    function verifyAccess(key) {

        if (key !== securityKey) {

            console.error("Unauthorized access detected!");

            document.body.innerHTML = "<h1>Access Denied</h1>";

            return;

        }

        accessGranted = true;

    }

    

    verifyAccess("K3yXp3rt_53cur3");

})();

/* === Device Connection Detection === */

let deviceStatus = {

    keyboard: false,

    mouse: false

};

/* Check USB & Bluetooth Connection */

window.addEventListener("gamepadconnected", function(e) {

    deviceStatus.keyboard = true;

    document.getElementById("status-keyboard").innerText = "Connected";

    document.getElementById("status-keyboard").style.color = "limegreen";

});

window.addEventListener("gamepaddisconnected", function(e) {

    deviceStatus.keyboard = false;

    document.getElementById("status-keyboard").innerText = "Disconnected";

    document.getElementById("status-keyboard").style.color = "red";

});

/* === Key Mapping System === */

const keyBindings = {};

const macroScripts = {};

document.addEventListener("keydown", function(event) {

    if (keyBindings[event.code]) {

        executeMacro(keyBindings[event.code]);

    }

});

/* Save Key Mappings */

function saveKeyMapping(key, action) {

    keyBindings[key] = action;

    localStorage.setItem("keyMappings", JSON.stringify(keyBindings));

}

/* Load Key Mappings */

function loadKeyMappings() {

    const savedMappings = localStorage.getItem("keyMappings");

    if (savedMappings) {

        Object.assign(keyBindings, JSON.parse(savedMappings));

    }

}

loadKeyMappings();

/* === Macro Scripting System === */

function saveMacro(key, script) {

    macroScripts[key] = script;

    localStorage.setItem("macroScripts", JSON.stringify(macroScripts));

}

function executeMacro(key) {

    if (macroScripts[key]) {

        eval(macroScripts[key]);

    }

}

/* === Mouse Sensitivity Adjustment === */

let mouseSensitivity = 1;

document.getElementById("mouse-sensitivity").addEventListener("input", function(event) {

    mouseSensitivity = event.target.value / 100;

});

/* === 360° Mouse Rotation for FPS Games === */

document.addEventListener("mousemove", function(event) {

    if (deviceStatus.mouse) {

        let xMovement = event.movementX * mouseSensitivity;

        let yMovement = event.movementY * mouseSensitivity;

        // Apply rotation to the game

    }

});

/* === Auto Game Launcher === */

function launchGame() {

    let game = document.getElementById("game-selector").value;

    if (game === "freefire") {

        window.open("freefire://launch", "_blank");

    } else if (game === "pubg") {

        window.open("pubg://launch", "_blank");

    } else if (game === "minecraft") {

        window.open("minecraft://launch", "_blank");

    }

}

document.getElementById("launch-game").addEventListener("click", launchGame);

/* === Game Overlay System === */

const overlay = document.getElementById("game-overlay");

let overlayVisible = false;

function toggleOverlay() {

    overlayVisible = !overlayVisible;

    overlay.style.display = overlayVisible ? "block" : "none";

}

/* === Final Security Lock === */

setInterval(() => {

    if (!deviceStatus.keyboard && !deviceStatus.mouse) {

        console.warn("No input devices detected!");

    }

}, 5000);